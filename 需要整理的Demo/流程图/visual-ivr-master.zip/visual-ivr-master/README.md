# 可视化IVR编辑器 base DEMO

直接在浏览器中打开index.html

各位，这个项目完全是我很久之前写着玩的，当时写的比较匆忙，代码太乱，我也没时间管了。各位凑合看吧。 

查看在线demo: https://wdd.js.org/visual-ivr/

![](./Jietu20181226-123854.jpg)
